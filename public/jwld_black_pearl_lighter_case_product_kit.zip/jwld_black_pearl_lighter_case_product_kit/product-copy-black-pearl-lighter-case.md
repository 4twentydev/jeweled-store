# Black Pearl Rhinestone Lighter Case

**Subtitle:** Glossy black lighter sleeve with pearl-white rhinestone waves.

**Suggested price:** $18.00-24.00

## Short Description
A black rhinestone lighter case wrapped in pearl-white wave detailing for a clean, high-contrast sparkle.

## Full Product Description
The Black Pearl Rhinestone Lighter Case gives a standard pocket lighter a polished JWLD upgrade. Glossy black stones create the base while pearl-white rhinestones flow in a wavy pattern around the case, giving it a bold but wearable contrast. It is small, eye-catching, and made for daily carry, display trays, gift bundles, or custom 420-friendly accessory drops.

## Features
- Hand-decorated rhinestone lighter sleeve
- Black base with pearl-white wave pattern
- Fits standard full-size disposable lighter shape
- Reusable case design; lighter can be swapped out
- Great for gifts, display sets, and custom bundles

## Care
Keep dry when possible. Wipe gently with a soft cloth. Do not soak, scrape, or store loose with sharp items.

## SEO
**SEO title:** Black Pearl Rhinestone Lighter Case | JWLD.store

**SEO description:** Shop a black and pearl-white rhinestone lighter case from JWLD.store. A reusable bling lighter sleeve with bold wave detailing.

**Image alt text:** Black lighter case covered in black and pearl-white rhinestones in a wave pattern.
